
package co.edu.poli.ces2;

//import java.io.IOException;
//import java.lang.reflect.Array;
//import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author guillo
 */
public class ObjetoSQL {
    
    private String tabla;
    private List<String> columnas;
    private Integer cantidadPK;
    private List<String> primaryKey;
    private Integer cantidadColAutoInc;
    private List<String> colAutoInc;
    private List<String> tipoDato;
    private String paquete;
    

    public String getPaquete() {
        return paquete;
    }

    public void setPaquete(String string) {
        paquete = string;
    }
    
    public String getNombreTabla() {
        return tabla;
    }

    public void setNombreTabla(String string) {
        tabla = string;
    }
    
    public List<String> getColumnas() {
        return columnas;
    }

    public void setColumnas(String string) {
        try{
            
            List<String> colCapital;
            colCapital = new ArrayList<>();
            String[] columna;
            this.columnas = null;
            columna = string.split("\\s+");
            for (String x : columna){
                String y = capitalizar(x);
                colCapital.add(y);
            }
            columnas = colCapital;
        }catch(Exception e){
            System.out.println("Error cols " + e);
        }
    }
    
    public int getCantidadPK(){
        return cantidadPK;
    }

    public void setCantidadPK(Integer cantidad){
        cantidadPK = cantidad;
    }
    
    public List<String> getPrimaryKey(){
        return primaryKey;
    }

    public void setPrimaryKey(String string) {
        try{
            String[] columna = string.split("\\s+");
            primaryKey = Arrays.asList(columna);
        }catch(Exception e){
            System.out.println(" error PK " + e);
        }
    }

    public int getCantidadColAutoInc(){
        return cantidadColAutoInc;
    }

    public void setCantidadColAutoInc(Integer cantidad){
        cantidadColAutoInc = cantidad;
    }
    
    public List<String> getColAutoInc(){
        return colAutoInc;
    }

    public void setColAutoInc(String string) {
        try{
            String [] columna = string.split("\\s+");
            colAutoInc = Arrays.asList(columna);
        }catch(Exception e){
            System.out.println("error colsinc " + e);
        }
    }

    public List<String> getTipoDato() {
        return tipoDato;
    }

    public void setTipoDato(String string) {
        String [] columna = string.split(",");
        tipoDato = Arrays.asList(columna);
    }
    
    private static String capitalizar(String string) {
        char[] caracter = string.toLowerCase().toCharArray();
        boolean bandera = false;
        for (int i = 0; i < caracter.length; i++) {
          if (!bandera && Character.isLetter(caracter[i])) {
            caracter[i] = Character.toUpperCase(caracter[i]);
            bandera = true;
          } else if (Character.isWhitespace(caracter[i]) || +
                  caracter[i]=='.' || caracter[i]=='\'') {
            bandera = false;
          }
        }
        return String.valueOf(caracter);
    }

}
