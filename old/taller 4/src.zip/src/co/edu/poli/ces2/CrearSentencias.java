
package co.edu.poli.ces2;

//import java.lang.reflect.Method;

/**
 *
 * @author guillo
 */
public class CrearSentencias {
    
    /**
     * Objeto publico para que se pueda llamar de todas las funciones sin necesidad de pasarlo a cada una
     */
    private static ObjetoSQL objetoX;
    private final String nL = System.getProperty("line.separator");
    private final String tb = "\t";
    
    
    public String crearSentencias(short sentencia, ObjetoSQL objeto){
        
        CrearSentencias.objetoX = objeto;
        String cadena;
        cadena = "";
        switch(sentencia){
            case 1:
                cadena = paquete();
                break;
            case 2:
                cadena = imports();
                break;
            case 3:
                cadena = clase();
                break;
            case 4:
                cadena = columnas();
                break;
            case 5:
                cadena = inicializador();
                break;
            case 6:
                cadena = geters();
                break;
            case 7:
                cadena = seters();
                break;
            case 8:
                cadena = "}";
            default:
                break;
        }
        return cadena;
    }
    
    private String paquete(){
        String sentencia;
        sentencia = "package " + objetoX.getPaquete() + ";" + nL;
        return sentencia;
    }
    
    private String imports(){
        String sentencia = "";
        for (String x : objetoX.getTipoDato()){
            if (x.contains("Timestamp")){
                sentencia = "import java.sql.Timestamp;" + nL;
                return sentencia;
            }else{
                sentencia = nL;
            }
        }
        return sentencia;
    }
    
    private String clase(){
        String sentencia;
        sentencia = "public class " + objetoX.getNombreTabla() + "{" + nL;
        return sentencia;
    }
    
    private String columnas(){
        String sentencia = "";
        int numeroPK, numeroAI, cont;
        cont = 0;
        numeroPK = objetoX.getCantidadPK();
        numeroAI = objetoX.getCantidadColAutoInc();
        for (String x : objetoX.getColumnas()){
            sentencia += tb + "@Columna";
            if (cont < numeroPK){
                sentencia += "(ClavePrimaria = true";
                if (cont < numeroAI){
                    sentencia += ", AutoNumerico = true)";
                }else{
                    sentencia += ")";
                }
            }else if (cont < numeroAI){
                sentencia += "(AutoNumerico = true)"; 
            }
            sentencia += nL + tb + "private " + objetoX.getTipoDato().get(cont) + 
                    " " + x + nL;
            cont++;
        }
        return sentencia;
    }
    
    private String inicializador(){
        String sentencia;
        System.out.println("inicializando");
        sentencia = tb + "public " +objetoX.getNombreTabla() + "() {" + nL + tb + "}" ;
        return sentencia;
    }
    
    private String geters(){
        String sentencia;
        int cont;
        cont = 0;
        sentencia = "";
        for (String x : objetoX.getTipoDato()){
            sentencia = sentencia + nL + tb + "public " + x + " " + "get" + 
            objetoX.getColumnas().get(cont) + "() {" + nL + tb + tb + "return " + 
            objetoX.getColumnas().get(cont) + ";" + nL + tb + "}" + nL;            
            cont++;
        }
        return sentencia;
    }
      
    private String seters(){
        String sentencia;
        int cont;
        cont = 0;
        sentencia = "";
        for (String x : objetoX.getColumnas()){System.out.println(x);}
        for (String x : objetoX.getTipoDato()){System.out.println(x);}
        for (String x : objetoX.getColumnas()){
            sentencia += tb + "public void set" + x + "(" +
                objetoX.getTipoDato().get(cont) + " " + x + "){" +
                nL + tb + tb + "this." + x + " = " + x + ";" + nL + tb + "}" + nL;
            cont++;
        }
        return sentencia;
    }
    
}
