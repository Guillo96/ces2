package co.edu.poli.ces2;


import java.io.File;
import java.io.IOException;

/**
 *
 * @author guillo
 */
public class CrearDirectorio {

    
    /**
     * Crea un directorio en la ruta que recibe como string
     * Retorna el directorio
     */
    public void crearDirectorio(final String string) throws IOException{
        
        File ruta;
        ruta = new File(string.replace(".", "/"));
        if (!ruta.exists() && !ruta.mkdirs()) {
            throw new IOException("No se puede crear " + ruta.getAbsolutePath());
        }
        
    }
}
