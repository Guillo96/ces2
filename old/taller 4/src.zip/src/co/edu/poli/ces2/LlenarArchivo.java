package co.edu.poli.ces2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author guillo
 */
public class LlenarArchivo {

    public void llenarArchivo(ObjetoSQL objeto, String directorio) {

        String nombreArchivo;
        String sentencia;
        
        try {
            nombreArchivo = directorio.replace(".", "/");
            nombreArchivo += "/" + objeto.getNombreTabla() + ".java";
            FileWriter escritor = new FileWriter(nombreArchivo, true);
            BufferedWriter bufferEscritura = new BufferedWriter(escritor);

            /**
             * Creamos la clase
             * Los 8 pasos existentes son las secuencias de string que
             * crea la clase CrearSentencias que devuelve los string
             * y aca los aderimos al archivo
             */
            for (short i = 1; i < 9; i++) {
                CrearSentencias crear = new CrearSentencias();
                sentencia = crear.crearSentencias(i, objeto);
                bufferEscritura.append(sentencia);
                bufferEscritura.newLine();
            }

            System.out.println("Guardando clase " + objeto.getNombreTabla() + ".java");
            bufferEscritura.close();
            escritor.close();
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }

    }
}
