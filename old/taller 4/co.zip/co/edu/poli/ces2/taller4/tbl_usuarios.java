package co.edu.poli.ces2.taller4;

import java.sql.Timestamp;

public class tbl_usuarios{

	@Columna(ClavePrimaria = true)
	private String Id_usuario
	@Columna
	private String Nombre
	@Columna
	private String Apellido
	@Columna
	private String Clave
	@Columna
	private String Correo
	@Columna
	private String Mod_usuario
	@Columna
	private java.sql.Timestamp Mod_fecha

	public tbl_usuarios() {
	}

	public String getId_usuario() {
		return Id_usuario;
	}

	public String getNombre() {
		return Nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public String getClave() {
		return Clave;
	}

	public String getCorreo() {
		return Correo;
	}

	public String getMod_usuario() {
		return Mod_usuario;
	}

	public java.sql.Timestamp getMod_fecha() {
		return Mod_fecha;
	}

	public void setId_usuario(String Id_usuario){
		this.Id_usuario = Id_usuario;
	}
	public void setNombre(String Nombre){
		this.Nombre = Nombre;
	}
	public void setApellido(String Apellido){
		this.Apellido = Apellido;
	}
	public void setClave(String Clave){
		this.Clave = Clave;
	}
	public void setCorreo(String Correo){
		this.Correo = Correo;
	}
	public void setMod_usuario(String Mod_usuario){
		this.Mod_usuario = Mod_usuario;
	}
	public void setMod_fecha(java.sql.Timestamp Mod_fecha){
		this.Mod_fecha = Mod_fecha;
	}

}
