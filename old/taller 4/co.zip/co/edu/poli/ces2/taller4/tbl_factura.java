package co.edu.poli.ces2.taller4;

import java.sql.Timestamp;

public class tbl_factura{

	@Columna(ClavePrimaria = true, AutoNumerico = true)
	private Integer Id_factura
	@Columna
	private Integer Id_cliente
	@Columna
	private java.sql.Timestamp Fecha
	@Columna
	private String Observaciones

	public tbl_factura() {
	}

	public Integer getId_factura() {
		return Id_factura;
	}

	public Integer getId_cliente() {
		return Id_cliente;
	}

	public java.sql.Timestamp getFecha() {
		return Fecha;
	}

	public String getObservaciones() {
		return Observaciones;
	}

	public void setId_factura(Integer Id_factura){
		this.Id_factura = Id_factura;
	}
	public void setId_cliente(Integer Id_cliente){
		this.Id_cliente = Id_cliente;
	}
	public void setFecha(java.sql.Timestamp Fecha){
		this.Fecha = Fecha;
	}
	public void setObservaciones(String Observaciones){
		this.Observaciones = Observaciones;
	}

}
