package co.edu.poli.ces2.taller4;



public class tbl_factura_detalle{

	@Columna(ClavePrimaria = true)
	private Integer Id_factura
	@Columna(ClavePrimaria = true)
	private Integer Item
	@Columna
	private Integer Id_producto
	@Columna
	private Double Cantidad
	@Columna
	private Double Costo_unitario
	@Columna
	private String Observaciones

	public tbl_factura_detalle() {
	}

	public Integer getId_factura() {
		return Id_factura;
	}

	public Integer getItem() {
		return Item;
	}

	public Integer getId_producto() {
		return Id_producto;
	}

	public Double getCantidad() {
		return Cantidad;
	}

	public Double getCosto_unitario() {
		return Costo_unitario;
	}

	public String getObservaciones() {
		return Observaciones;
	}

	public void setId_factura(Integer Id_factura){
		this.Id_factura = Id_factura;
	}
	public void setItem(Integer Item){
		this.Item = Item;
	}
	public void setId_producto(Integer Id_producto){
		this.Id_producto = Id_producto;
	}
	public void setCantidad(Double Cantidad){
		this.Cantidad = Cantidad;
	}
	public void setCosto_unitario(Double Costo_unitario){
		this.Costo_unitario = Costo_unitario;
	}
	public void setObservaciones(String Observaciones){
		this.Observaciones = Observaciones;
	}

}
