
package ces2_2014a;

/**
 *
 * @author thomas
 */
public class CES2_2014a {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        for (String par : args) {
            System.out.println(par);
        }
    }
    
}
